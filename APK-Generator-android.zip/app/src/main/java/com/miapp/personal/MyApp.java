package com.miapp.personal;
import android.app.Application;
public class MyApp extends Application { @Override public void onCreate() { super.onCreate(); } }