# APK Generator

App generada con App2APK.

## Información

| Campo | Valor |
|-------|-------|
| Package | `com.miapp.personal` |
| Versión | 1.0 (build 1) |
| Fuente | index (2).html |
| Min Android | API 21 |

## Compilar el APK

### Opción A — GitHub Actions (recomendado)
1. Sube este proyecto a un repositorio en [github.com](https://github.com)
2. Ve a **Actions** → el workflow corre automáticamente
3. Descarga el APK desde **Artifacts**

### Opción B — Android Studio
1. Abre este proyecto en Android Studio
2. **Build → Build Bundle(s) / APK(s) → Build APK(s)**
3. APK en: `app/build/outputs/apk/debug/app-debug.apk`

### Opción C — Línea de comandos
```bash
chmod +x gradlew
./gradlew assembleDebug
```

## Instalar en el celular
1. Transfiere el APK al celular
2. Abre el archivo en el celular
3. Si pide permiso: **Ajustes → Instalar apps desconocidas → Permitir**

---
Generado con **App2APK** 🚀