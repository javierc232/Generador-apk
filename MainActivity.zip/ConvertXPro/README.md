# ConvertX Pro - Android App

Una aplicación Android nativa para editar documentos, insertar imágenes y exportar en múltiples formatos.

## 📋 Características

✅ **Editor de Texto**
- Formato básico (Bold, Italic, Underline)
- Contador de palabras y caracteres
- Autosave

✅ **Imágenes**
- Captura desde cámara
- Importar desde galería
- Redimensionamiento intuitivo
- Vista previa en el documento

✅ **Exportación**
- PDF
- DOCX (Word)
- TXT
- Guardado local en el dispositivo

✅ **Interfaz**
- Tema oscuro nativo
- Responsiva
- Fácil de usar

## 🚀 Instalación

### OPCIÓN 1: Compilar con Android Studio (Recomendado)

1. **Descargar Android Studio**: https://developer.android.com/studio
2. **Descargar el proyecto**: Descarga la carpeta `ConvertXPro`
3. **Abrir en Android Studio**:
   - Abre Android Studio
   - File > Open > Selecciona la carpeta `ConvertXPro`
   - Espera a que se indexe (2-3 minutos)
4. **Compilar**: 
   - Click en "Run" o presiona Shift + F10
   - Selecciona tu dispositivo o emulador
5. **¡Listo!** La app se instalará automáticamente

### OPCIÓN 2: Compilar desde línea de comandos

```bash
cd ConvertXPro
./gradlew build
./gradlew installDebug
```

### OPCIÓN 3: Usar GitHub Actions (APK automático)

1. Sube la carpeta a GitHub
2. Ve a Actions
3. GitHub compilará el APK automáticamente
4. Descarga desde Artifacts

## 📱 Requisitos

- **Android**: 7.0 (API 24) o superior
- **RAM**: 2GB mínimo
- **Almacenamiento**: 50MB libres

## 🔧 Permisos

La app solicita:
- `CAMERA`: Para capturar fotos
- `READ_EXTERNAL_STORAGE`: Para importar imágenes
- `WRITE_EXTERNAL_STORAGE`: Para guardar documentos

## 📂 Estructura

```
ConvertXPro/
├── app/
│   ├── src/
│   │   └── main/
│   │       ├── java/com/convertx/pro/
│   │       │   └── MainActivity.java
│   │       ├── res/
│   │       │   ├── layout/
│   │       │   │   └── activity_main.xml
│   │       │   ├── values/
│   │       │   │   ├── colors.xml
│   │       │   │   ├── strings.xml
│   │       │   │   └── themes.xml
│   │       │   └── xml/
│   │       │       └── file_paths.xml
│   │       └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
└── settings.gradle
```

## 🐛 Troubleshooting

### "Error: SDK no encontrado"
- Descarga el Android SDK desde Android Studio
- Tools > SDK Manager > Android 12.0+ (API 34)

### "Gradle sync failed"
- File > Sync Now
- File > Invalidate Caches > Restart

### "Permiso de cámara denegado"
- Abre Configuración > Aplicaciones > ConvertX Pro > Permisos
- Habilita Cámara y Almacenamiento

## 📝 Uso

1. **Escribir**: Toca el campo de texto
2. **Formatear**: Usa los botones B, I, U
3. **Agregar imagen**: 
   - 📷 para cámara
   - 🖼️ para galería
   - Toca la imagen para redimensionar
4. **Guardar**: 
   - PDF: Toca "📥 PDF"
   - DOCX: Toca "📥 DOCX"
   - TXT: Toca "📥 TXT"

Los archivos se guardan en: `/sdcard/Android/data/com.convertx.pro/files/`

## 📄 Licencia

MIT License - Libre para usar y modificar

## 👨‍💻 Desarrollado por

Javier - ConvertX Pro Team
