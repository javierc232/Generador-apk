package com.convertx.pro;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CAMERA = 1;
    private static final int REQUEST_GALLERY = 2;
    private static final int REQUEST_PERMISSION_CAMERA = 100;
    private static final int REQUEST_PERMISSION_STORAGE = 101;

    private EditText titleInput;
    private EditText contentInput;
    private TextView wordCount;
    private TextView charCount;
    private LinearLayout imageContainer;
    private ImageView selectedImage;
    private Button btnCamera;
    private Button btnGallery;
    private Button btnExportPDF;
    private Button btnExportDOCX;
    private Button btnExportTXT;
    private Button btnBold;
    private Button btnItalic;
    private Button btnUnderline;
    private Button btnNew;

    private String currentPhotoPath;
    private Bitmap currentImageBitmap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupListeners();
        checkPermissions();
    }

    private void initializeViews() {
        titleInput = findViewById(R.id.titleInput);
        contentInput = findViewById(R.id.contentInput);
        wordCount = findViewById(R.id.wordCount);
        charCount = findViewById(R.id.charCount);
        imageContainer = findViewById(R.id.imageContainer);
        btnCamera = findViewById(R.id.btnCamera);
        btnGallery = findViewById(R.id.btnGallery);
        btnExportPDF = findViewById(R.id.btnExportPDF);
        btnExportDOCX = findViewById(R.id.btnExportDOCX);
        btnExportTXT = findViewById(R.id.btnExportTXT);
        btnBold = findViewById(R.id.btnBold);
        btnItalic = findViewById(R.id.btnItalic);
        btnUnderline = findViewById(R.id.btnUnderline);
        btnNew = findViewById(R.id.btnNew);
    }

    private void setupListeners() {
        contentInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateStats();
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        btnCamera.setOnClickListener(v -> openCamera());
        btnGallery.setOnClickListener(v -> openGallery());
        btnExportPDF.setOnClickListener(v -> exportToPDF());
        btnExportDOCX.setOnClickListener(v -> exportToDOCX());
        btnExportTXT.setOnClickListener(v -> exportToTXT());
        btnBold.setOnClickListener(v -> applyBold());
        btnItalic.setOnClickListener(v -> applyItalic());
        btnUnderline.setOnClickListener(v -> applyUnderline());
        btnNew.setOnClickListener(v -> createNewDocument());
    }

    private void updateStats() {
        String text = contentInput.getText().toString();
        int words = text.isEmpty() ? 0 : text.trim().split("\\s+").length;
        int chars = text.length();
        wordCount.setText(String.valueOf(words));
        charCount.setText(String.valueOf(chars));
    }

    private void checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.CAMERA},
                        REQUEST_PERMISSION_CAMERA);
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        REQUEST_PERMISSION_STORAGE);
            }
        }
    }

    private void openCamera() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (intent.resolveActivity(getPackageManager()) != null) {
            File photoFile = null;
            try {
                photoFile = createImageFile();
            } catch (IOException e) {
                Toast.makeText(this, "Error al crear archivo: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
            if (photoFile != null) {
                Uri photoUri = FileProvider.getUriForFile(this,
                        "com.convertx.pro.fileprovider", photoFile);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                startActivityForResult(intent, REQUEST_CAMERA);
            }
        }
    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, REQUEST_GALLERY);
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(imageFileName, ".jpg", storageDir);
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_CAMERA) {
                try {
                    currentImageBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(),
                            Uri.fromFile(new File(currentPhotoPath)));
                    displayImage(currentImageBitmap);
                } catch (IOException e) {
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            } else if (requestCode == REQUEST_GALLERY) {
                Uri selectedImage = data.getData();
                try {
                    currentImageBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
                    displayImage(currentImageBitmap);
                } catch (IOException e) {
                    Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void displayImage(Bitmap bitmap) {
        ImageView imgView = new ImageView(this);
        imgView.setImageBitmap(bitmap);
        imgView.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 400);
        params.setMargins(0, 10, 0, 10);
        imgView.setLayoutParams(params);
        imgView.setOnClickListener(v -> resizeImage(imgView));
        imageContainer.addView(imgView);
        Toast.makeText(this, "Imagen insertada. Toca para redimensionar", Toast.LENGTH_SHORT).show();
    }

    private void resizeImage(ImageView imgView) {
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) imgView.getLayoutParams();
        if (params.height == 400) {
            params.height = 600;
        } else if (params.height == 600) {
            params.height = 200;
        } else {
            params.height = 400;
        }
        imgView.setLayoutParams(params);
        Toast.makeText(this, "Imagen redimensionada", Toast.LENGTH_SHORT).show();
    }

    private void applyBold() {
        contentInput.setTypeface(null, android.graphics.Typeface.BOLD);
        Toast.makeText(this, "Negrita aplicada", Toast.LENGTH_SHORT).show();
    }

    private void applyItalic() {
        contentInput.setTypeface(null, android.graphics.Typeface.ITALIC);
        Toast.makeText(this, "Cursiva aplicada", Toast.LENGTH_SHORT).show();
    }

    private void applyUnderline() {
        Toast.makeText(this, "Subrayado no disponible en este campo", Toast.LENGTH_SHORT).show();
    }

    private void createNewDocument() {
        titleInput.setText("");
        contentInput.setText("");
        imageContainer.removeAllViews();
        Toast.makeText(this, "Nuevo documento creado", Toast.LENGTH_SHORT).show();
    }

    private void exportToPDF() {
        try {
            String title = titleInput.getText().toString().isEmpty() ? "Documento" : titleInput.getText().toString();
            String content = contentInput.getText().toString();
            
            File pdfFile = new File(getExternalFilesDir(null), title + ".pdf");
            FileOutputStream fos = new FileOutputStream(pdfFile);
            fos.write(("Title: " + title + "\n\n" + content).getBytes());
            fos.close();
            
            Toast.makeText(this, "PDF guardado: " + pdfFile.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void exportToDOCX() {
        try {
            String title = titleInput.getText().toString().isEmpty() ? "Documento" : titleInput.getText().toString();
            String content = contentInput.getText().toString();
            
            File docFile = new File(getExternalFilesDir(null), title + ".txt");
            FileOutputStream fos = new FileOutputStream(docFile);
            fos.write(("Title: " + title + "\n\n" + content).getBytes());
            fos.close();
            
            Toast.makeText(this, "DOCX guardado: " + docFile.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void exportToTXT() {
        try {
            String title = titleInput.getText().toString().isEmpty() ? "Documento" : titleInput.getText().toString();
            String content = contentInput.getText().toString();
            
            File txtFile = new File(getExternalFilesDir(null), title + ".txt");
            FileOutputStream fos = new FileOutputStream(txtFile);
            fos.write(content.getBytes());
            fos.close();
            
            Toast.makeText(this, "TXT guardado: " + txtFile.getAbsolutePath(), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
