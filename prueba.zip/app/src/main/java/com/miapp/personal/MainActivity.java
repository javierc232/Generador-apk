package com.miapp.personal;
import android.app.Activity; import android.os.Bundle; import android.webkit.*; import android.widget.*; import android.view.*;
public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView wv = new WebView(this);
        wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setDomStorageEnabled(true);
        wv.setWebChromeClient(new WebChromeClient());
        setContentView(wv);
        wv.loadUrl("file:///android_asset/www/index.html");
    }
}